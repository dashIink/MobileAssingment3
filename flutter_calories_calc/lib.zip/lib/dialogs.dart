// dialogs.dart
import 'package:flutter/material.dart';
import 'databasehelper.dart';
import 'mealplan.dart';

void showMealPlanDialog(BuildContext context, List<String> mealPlanItems, String date) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Meal Plan for $date'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Selected Food Items:'),
              for (String item in mealPlanItems)
                Text('- $item'),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              _handleDeleteAction(context, date);
            },
            child: Text('Delete'),
          ),
          ElevatedButton(
            onPressed: () {
              _handleUpdateAction(context, date);
            },
            child: Text('Update'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close the dialog
            },
            child: Text('OK'),
          ),
        ],
      );
    },
  );
}

void _handleDeleteAction(BuildContext context, String date) async {
  await DatabaseHelper().deleteMealPlan(date);
  Navigator.of(context).pop();
  print('Delete action for $date');
}

void _handleUpdateAction(BuildContext context, String date) {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => MealPlanScreen(selectedDate: date)),
  );
  print('Update action for $date');
}

void showNoMealPlanDialog(BuildContext context) {
  // Implement your logic to inform the user that no meal plan was found for the selected date.
}

void showDateEmptyDialog(BuildContext context) {
  // Implement your logic to inform the user that the date field is empty.
}